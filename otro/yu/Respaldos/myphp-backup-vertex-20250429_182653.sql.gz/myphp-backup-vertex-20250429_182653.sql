CREATE DATABASE IF NOT EXISTS `vertex`;

USE `vertex`;

SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `cajero`;

CREATE TABLE `cajero` (
  `id_cajero` int(11) NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) NOT NULL,
  PRIMARY KEY (`id_cajero`),
  UNIQUE KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `cajero_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;



DROP TABLE IF EXISTS `cargo`;

CREATE TABLE `cargo` (
  `id_cargo` int(11) NOT NULL AUTO_INCREMENT,
  `nom_cargo` int(11) NOT NULL,
  `estado_cargo` varchar(10) NOT NULL,
  PRIMARY KEY (`id_cargo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;



DROP TABLE IF EXISTS `categoria`;

CREATE TABLE `categoria` (
  `id_categoria` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_categoria` varchar(40) NOT NULL,
  `estado_categoria` varchar(10) NOT NULL,
  PRIMARY KEY (`id_categoria`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

INSERT INTO `categoria` VALUES (1,"Golosinas",1),
(2,"Barquillas",1),
(3,"Tortas",1),
(4,"pan",1),
(5,"Maltedas",1),
(6,"frituras",1);


DROP TABLE IF EXISTS `categoria_gasto`;

CREATE TABLE `categoria_gasto` (
  `id_categoria_gasto` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_categoria_gasto` varchar(40) NOT NULL,
  `estado_categoria_gasto` varchar(10) NOT NULL,
  PRIMARY KEY (`id_categoria_gasto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;



DROP TABLE IF EXISTS `cliente_generico`;

CREATE TABLE `cliente_generico` (
  `id_cliente_generico` int(11) NOT NULL AUTO_INCREMENT,
  `cedula` varchar(14) NOT NULL,
  `nombre` varchar(40) NOT NULL,
  `id_cajero` int(11) NOT NULL,
  PRIMARY KEY (`id_cliente_generico`),
  KEY `id_cajero` (`id_cajero`),
  CONSTRAINT `cliente_generico_ibfk_1` FOREIGN KEY (`id_cajero`) REFERENCES `cajero` (`id_cajero`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;



DROP TABLE IF EXISTS `cliente_mayor`;

CREATE TABLE `cliente_mayor` (
  `id_cliente_mayor` int(11) NOT NULL AUTO_INCREMENT,
  `cedula_identidad` varchar(14) NOT NULL,
  `nombre` varchar(40) NOT NULL,
  `apellido` varchar(40) NOT NULL,
  `telefono` varchar(20) NOT NULL,
  `correo` varchar(40) NOT NULL,
  `direccion` varchar(100) NOT NULL,
  `id_cajero` int(11) NOT NULL,
  PRIMARY KEY (`id_cliente_mayor`),
  KEY `id_cajero` (`id_cajero`),
  CONSTRAINT `cliente_mayor_ibfk_1` FOREIGN KEY (`id_cajero`) REFERENCES `cajero` (`id_cajero`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;



DROP TABLE IF EXISTS `cliente_mayor_pendiente`;

CREATE TABLE `cliente_mayor_pendiente` (
  `id_cliente_mayor_credito` int(11) NOT NULL AUTO_INCREMENT,
  `id_cliente_mayor` int(11) NOT NULL,
  `id_credito` int(11) NOT NULL,
  PRIMARY KEY (`id_cliente_mayor_credito`),
  KEY `id_cliente_mayor` (`id_cliente_mayor`,`id_credito`),
  KEY `id_credito` (`id_credito`),
  CONSTRAINT `cliente_mayor_pendiente_ibfk_1` FOREIGN KEY (`id_credito`) REFERENCES `credito` (`id_credito`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `cliente_mayor_pendiente_ibfk_2` FOREIGN KEY (`id_cliente_mayor`) REFERENCES `cliente_mayor` (`id_cliente_mayor`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;



DROP TABLE IF EXISTS `credito`;

CREATE TABLE `credito` (
  `id_credito` int(11) NOT NULL AUTO_INCREMENT,
  `producto` varchar(40) NOT NULL,
  `deuda` varchar(40) NOT NULL,
  `abono` varchar(40) NOT NULL,
  `fecha` date NOT NULL,
  PRIMARY KEY (`id_credito`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;



DROP TABLE IF EXISTS `empleado`;

CREATE TABLE `empleado` (
  `cedula_emple` varchar(14) NOT NULL,
  `nombre_emp` varchar(40) NOT NULL,
  `apellido_emp` int(40) NOT NULL,
  `fecha_nacimiento` date NOT NULL,
  `telefono_emple` varchar(20) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `id_nomina` int(11) NOT NULL,
  `id_cargo` int(11) NOT NULL,
  `estado_empleado` varchar(10) NOT NULL,
  PRIMARY KEY (`cedula_emple`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_nomina` (`id_nomina`,`id_cargo`),
  KEY `id_cargo` (`id_cargo`),
  CONSTRAINT `empleado_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `empleado_ibfk_2` FOREIGN KEY (`id_cargo`) REFERENCES `cargo` (`id_cargo`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `empleado_ibfk_3` FOREIGN KEY (`id_nomina`) REFERENCES `nomina` (`id_nomina`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;



DROP TABLE IF EXISTS `empresa`;

CREATE TABLE `empresa` (
  `RIF_empresa` varchar(15) NOT NULL,
  `cedula_representante` varchar(14) NOT NULL,
  `nombre_representante` varchar(40) NOT NULL,
  `apellido_representante` varchar(40) NOT NULL,
  `telefono_representante` varchar(20) NOT NULL,
  `nombre_empresa` varchar(40) NOT NULL,
  `logo_empresa` blob NOT NULL,
  `id_usuario` int(11) NOT NULL,
  PRIMARY KEY (`RIF_empresa`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `empresa_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;



DROP TABLE IF EXISTS `fondo`;

CREATE TABLE `fondo` (
  `id_fondo` int(11) NOT NULL AUTO_INCREMENT,
  `fondo` varchar(40) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  PRIMARY KEY (`id_fondo`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `fondo_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

INSERT INTO `fondo` VALUES (1,1000,1),
(2,2000,2);


DROP TABLE IF EXISTS `gastos`;

CREATE TABLE `gastos` (
  `id_gastos` int(11) NOT NULL AUTO_INCREMENT,
  `cantidad_gasto` varchar(40) NOT NULL,
  `precio_gasto` varchar(40) NOT NULL,
  `fecha_gasto` date NOT NULL,
  `id_fondo` int(11) NOT NULL,
  `id_categoria_gasto` int(11) NOT NULL,
  PRIMARY KEY (`id_gastos`),
  KEY `id_fondo` (`id_fondo`,`id_categoria_gasto`),
  KEY `id_categoria_gasto` (`id_categoria_gasto`),
  CONSTRAINT `gastos_ibfk_1` FOREIGN KEY (`id_fondo`) REFERENCES `fondo` (`id_fondo`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `gastos_ibfk_2` FOREIGN KEY (`id_categoria_gasto`) REFERENCES `categoria_gasto` (`id_categoria_gasto`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;



DROP TABLE IF EXISTS `nomina`;

CREATE TABLE `nomina` (
  `id_nomina` int(11) NOT NULL AUTO_INCREMENT,
  `pago_des` varchar(40) NOT NULL,
  `fecha_nom` date NOT NULL,
  `id_tasa_dolar` int(11) NOT NULL,
  `id_fondo` int(11) NOT NULL,
  PRIMARY KEY (`id_nomina`),
  KEY `id_tasa_dolar` (`id_tasa_dolar`,`id_fondo`),
  KEY `id_fondo` (`id_fondo`),
  CONSTRAINT `nomina_ibfk_1` FOREIGN KEY (`id_fondo`) REFERENCES `fondo` (`id_fondo`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `nomina_ibfk_2` FOREIGN KEY (`id_tasa_dolar`) REFERENCES `tasa_dolar` (`id_tasa_dolar`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;



DROP TABLE IF EXISTS `perdida`;

CREATE TABLE `perdida` (
  `id_perdida` int(11) NOT NULL AUTO_INCREMENT,
  `cant` varchar(40) NOT NULL,
  `precio_perdida` varchar(40) NOT NULL,
  `fecha_perdida` date NOT NULL,
  `id_pro` int(11) NOT NULL,
  PRIMARY KEY (`id_perdida`),
  KEY `id_pro` (`id_pro`),
  CONSTRAINT `perdida_ibfk_1` FOREIGN KEY (`id_pro`) REFERENCES `producto` (`id_pro`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;



DROP TABLE IF EXISTS `producto`;

CREATE TABLE `producto` (
  `id_pro` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_producto` varchar(40) NOT NULL,
  `cantidad` varchar(40) NOT NULL,
  `precio` varchar(40) NOT NULL,
  `codigo` varchar(30) NOT NULL,
  `descrip_prod` varchar(100) NOT NULL,
  `id_tasa_dolar` int(11) NOT NULL,
  `id_categoria` int(11) NOT NULL,
  `id_fondo` int(11) DEFAULT NULL,
  `estado_producto` varchar(10) NOT NULL,
  PRIMARY KEY (`id_pro`),
  KEY `id_tasa_dolar` (`id_tasa_dolar`,`id_categoria`,`id_fondo`),
  KEY `id_categoria` (`id_categoria`),
  KEY `id_fondo` (`id_fondo`),
  CONSTRAINT `producto_ibfk_1` FOREIGN KEY (`id_categoria`) REFERENCES `categoria` (`id_categoria`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `producto_ibfk_2` FOREIGN KEY (`id_fondo`) REFERENCES `fondo` (`id_fondo`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

INSERT INTO `producto` VALUES (1,"torta fria",500,"0.545","T-F","Torta fria de galletas",1,3,NULL,1),
(2,"pan",0,"2.75","P-A","Pan relleno de arequipe",1,4,NULL,1),
(3,"helado g",20,2,"B-G","Barquilla con galleta de colores",3,2,NULL,1),
(4,"Malteada",300,"0.75","M-F","MAlteada de fresa",1,5,NULL,1),
(5,"papas",150,"0.46","P-20","Papa fritas con awa",4,1,NULL,1),
(6,"tostones",400,"1.2","F-78","tostones salados",4,6,NULL,1);


DROP TABLE IF EXISTS `producto_proveedor`;

CREATE TABLE `producto_proveedor` (
  `id_producto_proveedor` int(11) NOT NULL AUTO_INCREMENT,
  `RIF` varchar(15) NOT NULL,
  `id_pro` int(11) NOT NULL,
  `costo_compra` varchar(40) NOT NULL,
  `cantidad_compra` varchar(40) NOT NULL,
  `fecha` date NOT NULL,
  PRIMARY KEY (`id_producto_proveedor`),
  KEY `RIF` (`RIF`,`id_pro`),
  KEY `id_pro` (`id_pro`),
  CONSTRAINT `producto_proveedor_ibfk_1` FOREIGN KEY (`id_pro`) REFERENCES `producto` (`id_pro`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

INSERT INTO `producto_proveedor` VALUES (1,"R-285610759",3,5,20,"2025-04-29"),
(2,"R-285610759",4,"0.36",300,"2025-04-29"),
(3,"R-301076935",5,"0.11",150,"2025-04-29"),
(4,"R-7537367363",1,"0.86",500,"2025-04-29"),
(5,"R-7537367363",6,"0.86",400,"2025-04-29");


DROP TABLE IF EXISTS `productos_ventas`;

CREATE TABLE `productos_ventas` (
  `id_producto_ventas` int(11) NOT NULL AUTO_INCREMENT,
  `id_ventas` int(11) NOT NULL,
  `id_pro` int(11) NOT NULL,
  PRIMARY KEY (`id_producto_ventas`),
  KEY `id_ventas` (`id_ventas`,`id_pro`),
  KEY `id_pro` (`id_pro`),
  CONSTRAINT `productos_ventas_ibfk_1` FOREIGN KEY (`id_pro`) REFERENCES `producto` (`id_pro`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `productos_ventas_ibfk_2` FOREIGN KEY (`id_ventas`) REFERENCES `ventas` (`id_ventas`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;



DROP TABLE IF EXISTS `proveedor`;

CREATE TABLE `proveedor` (
  `RIF` varchar(15) NOT NULL,
  `nombre_provedor` varchar(40) NOT NULL,
  `telefono_pro` varchar(20) NOT NULL,
  `correo_pro` varchar(40) NOT NULL,
  `id_usuario` int(11) DEFAULT NULL,
  `estado_proveedor` varchar(10) NOT NULL,
  PRIMARY KEY (`RIF`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `proveedor_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

INSERT INTO `proveedor` VALUES ("R-285610759","Papas Jhon",04121234567,"hola@gmail.com",NULL,1),
("R-301076935","Las Julianas",04143268968,"damaris@gmail.com",NULL,1),
("R-7537367363","Ivam",04146789054,"ivan@gmail.com",NULL,1);


DROP TABLE IF EXISTS `tasa_dolar`;

CREATE TABLE `tasa_dolar` (
  `id_tasa_dolar` int(11) NOT NULL AUTO_INCREMENT,
  `tasa_dolar` varchar(40) NOT NULL,
  `fecha_dolar` date NOT NULL,
  `id_usuario` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_tasa_dolar`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `tasa_dolar_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;



DROP TABLE IF EXISTS `tipo_pago`;

CREATE TABLE `tipo_pago` (
  `id_tipo_pago` int(11) NOT NULL AUTO_INCREMENT,
  `tipo_pago` varchar(40) NOT NULL,
  PRIMARY KEY (`id_tipo_pago`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;



DROP TABLE IF EXISTS `tipo_usuario`;

CREATE TABLE `tipo_usuario` (
  `id_tipo_usuario` int(11) NOT NULL AUTO_INCREMENT,
  `tipo_usuario` varchar(40) NOT NULL,
  PRIMARY KEY (`id_tipo_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

INSERT INTO `tipo_usuario` VALUES (1,"Gerente"),
(2,"Cajero");


DROP TABLE IF EXISTS `usuario`;

CREATE TABLE `usuario` (
  `id_usuario` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_usuario` varchar(40) NOT NULL,
  `clave` varchar(30) NOT NULL,
  `id_tipo_usuario` int(11) NOT NULL,
  PRIMARY KEY (`id_usuario`),
  KEY `id_tipo_usuario` (`id_tipo_usuario`),
  CONSTRAINT `usuario_ibfk_1` FOREIGN KEY (`id_tipo_usuario`) REFERENCES `tipo_usuario` (`id_tipo_usuario`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

INSERT INTO `usuario` VALUES (1,"ivan",12345678,1),
(2,"damaris",897654321,2);


DROP TABLE IF EXISTS `ventas`;

CREATE TABLE `ventas` (
  `id_ventas` int(11) NOT NULL AUTO_INCREMENT,
  `fecha_venta` date NOT NULL,
  `id_cajero` int(11) NOT NULL,
  `id_fondo` int(11) NOT NULL,
  PRIMARY KEY (`id_ventas`),
  KEY `id_cajero` (`id_cajero`,`id_fondo`),
  KEY `id_fondo` (`id_fondo`),
  CONSTRAINT `ventas_ibfk_1` FOREIGN KEY (`id_cajero`) REFERENCES `cajero` (`id_cajero`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ventas_ibfk_2` FOREIGN KEY (`id_fondo`) REFERENCES `fondo` (`id_fondo`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;



DROP TABLE IF EXISTS `ventas_tipo_pago`;

CREATE TABLE `ventas_tipo_pago` (
  `id_ventas_tipo_pago` int(11) NOT NULL AUTO_INCREMENT,
  `id_tipo_pago` int(11) NOT NULL,
  `id_ventas` int(11) NOT NULL,
  PRIMARY KEY (`id_ventas_tipo_pago`),
  KEY `id_tipo_pago` (`id_tipo_pago`,`id_ventas`),
  KEY `id_ventas` (`id_ventas`),
  CONSTRAINT `ventas_tipo_pago_ibfk_1` FOREIGN KEY (`id_ventas`) REFERENCES `ventas` (`id_ventas`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ventas_tipo_pago_ibfk_2` FOREIGN KEY (`id_tipo_pago`) REFERENCES `tipo_pago` (`id_tipo_pago`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;



SET foreign_key_checks = 1;
